#include <iostream>

using namespace std;

int main()
{
    /*int angka = 10;
    float desimal = 10.5;
    string nama = "rizaldy";
    double tinggi = 10.4;
    char jenis_kelamin = 'L';
    bool isSunny = true;

    cout << "Angka: " << angka << endl;
    */


    /*int angka;

    cout << "Masukkan angka: ";
    cin >> angka;

    cout << "Angka: " << angka << endl;

    getch();
    */

    //operator aritmatika

    /*int angka1 = 10;
    int angka2 = 2;

    int hasil = angka1 % angka2;

    cout << "= " << hasil << endl;
    */

    //operator perbandingan

    /*int angka1 = 5;
    int angka2 = 5;

    bool hasil = (angka1 == angka2);

    cout << "= " << hasil << endl;
    */

    //operator logika

    /*bool kondisi1 = false;
    bool kondisi2 = false;

    bool hasil = (kondisi1 || kondisi2);
    cout << "= " << boolalpha << hasil << endl;
    */

    /*bool kondisi1 = false;
    bool hasil = !kondisi1;
    cout << "= " << boolalpha << hasil << endl;
    */

    //percabangan
    /*string kata;
    cout << "Masukkan kata = HALO" << endl;
    cin >> kata;

    if(kata == "HALO"){
        cout << "Kata sesuai" << endl;
    }

    else {
        cout << "Kata tidak sesuai" << endl;
    }
    */

    /*int tv;
     cout << "Daftar Channel tv" << endl;
     cout << "1. RCTI" << endl;
     cout << "2. INDOSIAR" << endl;

     cout << "Masukan channel pilihan: ";
     cin >> tv;

     switch(tv) {
     case 1 :
        cout << "Channel yang anda pilih RCTI" << endl;
        break;
     case 2 :
        cout << "Channel yang anda pilih INDOSIAR" << endl;
        break;
     default:
        cout << "Channel tidak tersedia" << endl;

     }
     */



    //perulangan
    /*int i;
    for (i=0; i<5; i++){
        cout << "Hello world" << endl;
    }
    */

    /*for(int i = 0; i<5; i++){
        cout << i+1 << " Hello world" << endl;
    }
    */

}

