#include <iostream>
#include <string>

using namespace std;

int main() {

    //Tugas no1
    /*float bilangan1, bilangan2;
    float hasil_tambah, hasil_kurang, hasil_kali, hasil_bagi;

    // Meminta input dari pengguna
    cout << "Masukkan bilangan pertama: ";
    cin >> bilangan1;

    cout << "Masukkan bilangan kedua: ";
    cin >> bilangan2;

    // Melakukan perhitungan
    hasil_tambah = bilangan1 + bilangan2;
    hasil_kurang = bilangan1 - bilangan2;
    hasil_kali = bilangan1 * bilangan2;
    hasil_bagi = bilangan1 / bilangan2;

    // Menampilkan hasil
    cout << "Hasil penjumlahan: " << hasil_tambah << endl;
    cout << "Hasil pengurangan: " << hasil_kurang << endl;
    cout << "Hasil perkalian: " << hasil_kali << endl;
    cout << "Hasil pembagian: " << hasil_bagi << endl;

    return 0;
    */


    //Tugas no 2

    /*int angka;
    string angka_dalam_tulisan;

    // Meminta input dari pengguna
    cout << "Masukkan angka (0-100): ";
    cin >> angka;

    // Validasi input
    if (angka < 0 || angka > 100) {
        cout << "Angka yang Anda masukkan tidak valid. Harap masukkan angka antara 0 sampai 100." << endl;
        return 1; // Keluar dari program dengan kode kesalahan
    }

    // Mengubah angka menjadi tulisan
    switch (angka) {
        case 0:  angka_dalam_tulisan = "nol"; break;
        case 1:  angka_dalam_tulisan = "satu"; break;
        // ... (tambahkan kasus untuk angka 2 sampai 100)
        case 100: angka_dalam_tulisan = "seratus"; break;
        default: cout << "Terjadi kesalahan dalam konversi." << endl; return 1;
    }

    // Menampilkan hasil
    cout << "Angka " << angka << " dalam tulisan adalah: " << angka_dalam_tulisan << endl;

    return 0;
    */


    //Tugas no 3
    /*int n;

    cout << "Masukkan angka: ";
    cin >> n;

    // Looping untuk setiap baris
    for (int i = n; i >= 1; i--) {
        // Looping untuk mencetak angka menurun
        for (int j = i; j >= 1; j--) {
            cout << j;
        }

        // Mencetak tanda '*'
        cout << "*";

        // Looping untuk mencetak angka menaik
        for (int j = 1; j <= i; j++) {
            cout << j;
        }

        // Pindah ke baris baru
        cout << endl;
    }

    // Mencetak tanda '*' di baris terakhir
    cout << "*";

    return 0;
    */
}
